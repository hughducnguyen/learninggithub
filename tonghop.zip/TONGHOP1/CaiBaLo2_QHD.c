
// Thuat toan Cai Ba Lo 2 ky thuat QUY HOACH DONG

#include <stdio.h>
#include <malloc.h>

typedef struct{
	char TenDv[20];
	int TL, GT, PA, SL;
}DoVat;

typedef int bang[50][100];

DoVat *ReadF(int *w, int *n){
	FILE *f;
	f = fopen("CaiBaLo2.txt", "r");
	fscanf(f, "%d", w);
	DoVat *dsdv;
	dsdv = (DoVat*)malloc(sizeof(DoVat));
	int i=0;
	while (!feof(f)){
		fscanf(f, "%d%d%d%[^\n]", &dsdv[i].TL, &dsdv[i].GT, &dsdv[i].SL, &dsdv[i].TenDv);
		dsdv[i].PA=0;
		i++;
		dsdv = (DoVat*)realloc(dsdv, sizeof(DoVat)*(i+1));
	}
	*n=i;
	fclose(f);
	return dsdv;
}

void in(DoVat *dsdv, int n, int w){
	int i, TongTL=0, TongGT=0;
	printf("Cai ba lo 1 bang phuong phap QUY HOACH DONG: \n");
	printf("|---|--------------------|----------|----------|----------|----------|\n");
	printf("|STT|      Ten DV        | T.Luong  | Gia Tri  |So Luong  | Phuong An|\n");
	printf("|---|--------------------|----------|----------|----------|----------|\n");
	for(i=0; i<n; i++){
		printf("|%2d |%-20s|%5d     |%5d     |%5d     |%5d     |\n", i+1, dsdv[i].TenDv, dsdv[i].TL, dsdv[i].GT, dsdv[i].SL, dsdv[i].PA);
		TongTL = TongTL + dsdv[i].PA * dsdv[i].TL;
		TongGT = TongGT + dsdv[i].PA * dsdv[i].GT;
	}
	printf("|---|--------------------|----------|----------|----------|----------|\n");
	printf("Tong trong luong cua balo: %d\n", w);
	printf("Tong trong luong: %d\n", TongTL);
	printf("Tong gia tri: %d", TongGT);
}

int min(int a, int b){
	return (a<b)?a:b;
}

void TaoBang(DoVat *dsdv, int n, int W, bang F, bang X){
	int xk, yk, k;
	int FMax, XMax, V;
	
	//Dong dau tien
	for(V=0;V<=W;V++){
		X[0][V] =min( V / dsdv[0].TL, dsdv[0].SL);
		F[0][V] = X[0][V] * dsdv[0].GT;
	}
	
	//Dong con lai
	for(k=1; k<n; k++)
		for(V=0; V<=W; V++){
			FMax = F[k-1][V];
			XMax = 0;
			yk =min(dsdv[k].SL, V / dsdv[k].TL);
			for(xk = 1; xk<=yk; xk++){
				if(F[k-1][V - xk*dsdv[k].TL] + xk*dsdv[k].GT > FMax){
					FMax = F[k-1][V - xk*dsdv[k].TL] + xk*dsdv[k].GT;
					XMax = xk;
				}
			}
			F[k][V] = FMax;
			X[k][V] = XMax;
		}
}


void InBang(int n, int W, bang F, bang X){
	int V, k;
	for( k=0; k<n; k++){
		for(V=0; V<=W; V++){
			printf("|%2d %2d", F[k][V], X[k][V]);
		}
		printf("|\n");
	}
}


void TraBang(DoVat *dsdv, int n, int W, bang X){
	int k, V=W;
	for(k=n-1; k>=0; k--){
		dsdv[k].PA = X[k][V];
		V = V - X[k][V]*dsdv[k].TL;
	}
}

int main(){
	int n, W;
	bang X, F;
	DoVat *dsdv;
	dsdv = ReadF(&W, &n);
	TaoBang(dsdv,n,W,F,X);
	InBang(n,W,F,X);
	printf("\n");
	TraBang(dsdv,n,W,X);
	in(dsdv,n,W);
}
